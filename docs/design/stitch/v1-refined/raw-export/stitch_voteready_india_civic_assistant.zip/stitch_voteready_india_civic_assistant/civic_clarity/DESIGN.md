---
name: Civic Clarity
colors:
  surface: '#f6faff'
  surface-dim: '#d2dbe4'
  surface-bright: '#f6faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ecf5fe'
  surface-container: '#e6eff8'
  surface-container-high: '#e0e9f2'
  surface-container-highest: '#dbe4ed'
  on-surface: '#141d23'
  on-surface-variant: '#44474e'
  inverse-surface: '#293138'
  inverse-on-surface: '#e9f2fb'
  outline: '#75777f'
  outline-variant: '#c5c6cf'
  surface-tint: '#4e5e81'
  primary: '#031635'
  on-primary: '#ffffff'
  primary-container: '#1a2b4b'
  on-primary-container: '#8293b8'
  inverse-primary: '#b6c6ef'
  secondary: '#8f4e00'
  on-secondary: '#ffffff'
  secondary-container: '#fe9832'
  on-secondary-container: '#683700'
  tertiary: '#001d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#013400'
  on-tertiary-container: '#3ca82c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#b6c6ef'
  on-primary-fixed: '#081b3a'
  on-primary-fixed-variant: '#364768'
  secondary-fixed: '#ffdcc2'
  secondary-fixed-dim: '#ffb77a'
  on-secondary-fixed: '#2e1500'
  on-secondary-fixed-variant: '#6d3a00'
  tertiary-fixed: '#8dfc75'
  tertiary-fixed-dim: '#72de5c'
  on-tertiary-fixed: '#012200'
  on-tertiary-fixed-variant: '#035300'
  background: '#f6faff'
  on-background: '#141d23'
  surface-variant: '#dbe4ed'
typography:
  headline-xl:
    fontFamily: Public Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.25'
  headline-md:
    fontFamily: Public Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Public Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
  source-tag:
    fontFamily: Public Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  container-margin: 20px
  gutter: 16px
---

## Brand & Style

The design system is built on the principles of **Modern Civic Minimalism**. It balances the weight of constitutional authority with the approachability of a modern digital service. The goal is to strip away the bureaucracy of typical government interfaces, replacing it with a "Calm Tech" aesthetic that reduces cognitive load for voters.

The brand personality is **Informed, Neutral, and Vital**. It avoids the aggressive visual language often associated with political campaigns, instead opting for a stable, source-transparent environment. By utilizing heavy whitespace and a refined color palette, this design system fosters trust and encourages civic participation among a digitally-native youth audience.

## Colors

The palette is anchored by **Deep Navy (#1A2B4B)**, signifying institutional stability and intelligence. This is contrasted against a **Soft Off-white (#F8F9FA)** background to reduce screen glare and create a premium, paper-like feel.

Cultural accents are applied with extreme restraint:
- **Warm Saffron (#FF9933)**: Used exclusively for low-priority alerts, "New" indicators, or warm highlights that require soft attention.
- **Vibrant Green (#138808)**: Used for verification badges, "Ready" states, and success feedback.
- **Grays**: A range of warm neutrals is used for borders and secondary text to maintain a soft, non-intimidating hierarchy.

The system prioritizes AA and AAA accessibility standards, ensuring high contrast between text and background layers.

## Typography

This design system utilizes **Public Sans**, an open-source typeface designed specifically for government and civic interfaces. It offers exceptional legibility across various screen qualities.

- **Headlines**: Use large, bold weights to create a welcoming "front door" experience. 
- **Body Text**: Generous line heights (1.5 - 1.6) are mandated to ensure long-form information regarding policy or voting procedures is easy to digest.
- **Data Labels**: Smaller, medium-weight labels are used for "Source" and "Last Updated" information, often paired with a subtle gray to indicate secondary importance without sacrificing readability.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a focus on generous internal padding. A strict 8px rhythmic scale governs all spacing.

- **Mobile First**: Layouts should prioritize a single-column view with 20px side margins to ensure tap targets are easily reachable.
- **Whitespace**: Content blocks must be separated by at least `lg` (40px) spacing to prevent the interface from feeling cluttered or "government-heavy."
- **Touch Targets**: All interactive elements (buttons, links, inputs) must maintain a minimum height of 48px to accommodate all users.

## Elevation & Depth

To maintain a "Calm" vibe, this design system avoids heavy shadows and floating effects. Instead, it uses **Tonal Layering** and **Low-Contrast Outlines**.

1.  **Level 0 (Base)**: Soft Off-white background.
2.  **Level 1 (Cards)**: White surfaces with a 1px border in a very light neutral (#E9ECEF).
3.  **Level 2 (Interactive)**: A very soft, highly diffused ambient shadow (Blur: 15px, Opacity: 4%, Color: Navy) is applied only to primary action cards to indicate interactivity.

This approach creates a flat, organized appearance that feels rooted and transparent rather than ethereal.

## Shapes

The shape language is defined by high-radius geometry to evoke friendliness and modern tech sensibilities.

- **Cards**: Use a radius between 16px and 24px (rounded-lg to rounded-xl) to soften the information display.
- **Buttons**: Fully rounded (pill-shaped) for primary actions to distinguish them from content containers.
- **Input Fields**: 12px radius to balance the card geometry without appearing too circular.
- **Icons**: Contained within rounded-square frames with a 25% corner radius for a cohesive, app-like look.

## Components

### Buttons
Primary buttons use the Deep Navy background with white text. Secondary buttons use a Navy outline with a transparent background. All buttons must feature clear, sans-serif labels in medium weight.

### Rounded Cards
The core container for the design system. Cards should have a 16px-24px corner radius. Information inside cards must be grouped logically with a clear "Source" label at the bottom, separated by a thin hairline divider.

### Chips & Tags
Used for categories (e.g., "Registration," "Polling Booth"). These are small, low-contrast pills using the neutral gray scale or very faint tints of Saffron/Green to denote status without being distracting.

### Progress Indicators
Steppers for "Voter Journey" workflows should be clean, using the Green accent to show completion. The path is represented by simple 4px thick lines.

### Transparency Labels
A specific component for "Source Verification." A small icon (shield or document) paired with "Verified Source: [Department Name]" text in the `source-tag` style, anchored to the bottom of information cards.